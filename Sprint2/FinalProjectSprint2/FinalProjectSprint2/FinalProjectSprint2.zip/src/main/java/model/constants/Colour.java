//Colour для цветов red и green — это цвета яблок.
//В них все поля должны быть public static final.

package model.constants;

public final class Colour {
    public static final String RED_APPLE = "red";
    public static final String GREEN_APPLE = "green";
}

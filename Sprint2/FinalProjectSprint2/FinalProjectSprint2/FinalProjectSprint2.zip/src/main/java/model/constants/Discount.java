//Discount для значений скидок

package model.constants;

public final class Discount {
    public static final double CURRENT_DISCOUNT = 60;
}
